/* This file has been automatically generated.  Do not edit. */

#ifndef _ANACRON_PATHS_H_
#define _ANACRON_PATHS_H_
#define ANACRON_SPOOL_DIR "/usr/local/var/spool/anacron"
#define ANACRONTAB "/usr/local/etc/anacrontab"
#endif /* _ANACRON_PATHS_H_ */
